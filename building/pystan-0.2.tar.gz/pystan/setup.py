
import os

from distutils.core import setup

setup(	name='pyStan',
	version='0.1.0',
	package_dir = {'': 'src'},
	packages = ['pystan', 'pystan.lib'],
	scripts=['src/pystan/pystan'],
	data_files = [
		('share/pixmaps',             ['src/pystan/res/desktop/pystan_icon_26x26.png']),
		('share/applications/hildon', ['src/pystan/res/desktop/pystan.desktop']),
    ]
)
