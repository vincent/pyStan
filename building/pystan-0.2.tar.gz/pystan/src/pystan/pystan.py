#!/usr/bin/env python2.5

import sys
import pygtk
pygtk.require('2.0')

from lib.gui import StanGUI

app = StanGUI()
app.run()
