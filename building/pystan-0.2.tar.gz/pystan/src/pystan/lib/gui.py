# -*- coding: UTF-8 -*-

import gtk
import hildon
import webbrowser

import sys, time

from stan import STAN
from timetable import StanTimetable

class StanGUI(hildon.Program):
    #
    def __init__(self):
        hildon.Program.__init__(self)
        self.stan = STAN()
        self.window = hildon.Window()
        self.window.set_title('pySTAN')

        self.window.connect("destroy", gtk.main_quit)
        self.window.connect("key-press-event", self.on_key_press)
        self.window.connect("window-state-event", self.on_window_state_change)
        self.window_in_fullscreen = False

        self.add_window(self.window)

        self.tabs = self.main_tabs()
        self.window.add(self.tabs)
        #
        self.last_station = False

    def on_window_state_change(self, widget, event, *args):
        self.window_in_fullscreen = (event.new_window_state & gtk.gdk.WINDOW_STATE_FULLSCREEN)

    def on_key_press(self, widget, event, *args):
        if event.keyval == gtk.keysyms.F6:
            # The "Full screen" hardware key has been pressed
            if self.window_in_fullscreen:
                self.window.unfullscreen ()
            else:
                self.window.fullscreen ()

    def main_tabs(self):
    	tabs = gtk.Notebook()
    	tabs.set_tab_pos(gtk.POS_TOP)
    	tabs.append_page(self.tab_lines(), gtk.Label('Par lignes'))
    	#tabs.append_page(self.tab_stations(), gtk.Label('Par arrets'))
        #tabs.append_page(self.tab_search(), gtk.Label('Recherche'))
    	return tabs
        #
    def tab_search(self):
    	tab_search = gtk.Frame(None) #'Recherche de trajet')

        from_location = gtk.Entry()
        from_location_label = gtk.Label(u"Départ")
        from_city = gtk.Entry()
        from_city_label = gtk.Label(u"à")

        to_location = gtk.Entry()
        to_location_label = gtk.Label(u"Arrivée")
        to_city = gtk.Entry()
        to_city_label = gtk.Label(u"à")

        datetime_select = gtk.Calendar()
        datetime_select.display_options(gtk.CALENDAR_SHOW_DAY_NAMES | gtk.CALENDAR_WEEK_START_MONDAY)

        restriction = gtk.Combo()
        restriction.set_popdown_strings([u"partir après", u"arriver avant"])

        vbox = gtk.VBox()
        vbox.add(from_location_label)
        vbox.add(from_location)
        vbox.add(from_city)
        vbox.add(to_location_label)
        vbox.add(to_location)
        vbox.add(to_city)

        vbox.add(datetime_select)
        vbox.add(restriction)

        tab_search.add(vbox)

        return tab_search

    # special callback for drawing line numbers in combo box
    def line_number_cell_cb(self, treeviewcolumn, cellrenderer, modele, iter):
        for line in self.stan.lines():
            cell_line_name = modele.get_value(iter, 1)
            cell_line_id = modele.get_value(iter, 2)

            if line['id'] == cell_line_id:
                text = '-'.join(line['numbers'])
                cellrenderer.set_property('text', text)

                if len(text) <= 10:
                    cellrenderer.set_property('scale', 0.8)
                else:
                    cellrenderer.set_property('scale', 0.6)

                if not line.has_key('fg-color'):
                    #print "ERROR:\tline %s do not have foreground color" % line['id']
                    pass
                else:
                    cellrenderer.set_property('foreground-gdk', gtk.gdk.color_parse(line['fg-color']))

                if not line.has_key('bg-color'):
                    #print "ERROR:\tline %s do not have background color" % line['id']
                    pass
                else:
                    cellrenderer.set_property('background-gdk', gtk.gdk.color_parse(line['bg-color']))
        return

    def set_previous_button_cb(self, callback):
        self._previous_button_cb = callback

    def _previous_button_cb(self, data):
        pass

    def set_active_lineid(self, lineid):
        pass

    def tab_lines(self):
    	tab_lines = gtk.Frame(None) #'Recherche par lignes')

        #lines_navigation = gtk.Table(rows=2, columns=2)
        lines_navigation = gtk.HBox()

        #previous_button = gtk.Button(u"<")
        #previous_button.connect('clicked', self._previous_button_cb)
        #alignment_previous_button = gtk.Alignment(xalign=0, xscale=0.02)
        #alignment_previous_button.add(previous_button)
        #lines_navigation.attach(previous_button, 0, 1, 0, 1, xoptions=gtk.SHRINK, yoptions=gtk.SHRINK, xpadding=1, ypadding=0)
        #lines_navigation.pack_start(previous_button)

        lines_list = gtk.ComboBox()
        lines_model = gtk.ListStore(str, str, int)
        lines_item_number = gtk.CellRendererText()
        lines_item_number.set_property('scale', 0.8)
        lines_item_name = gtk.CellRendererText()
        lines_item_name.set_property('scale', 0.8)

        lines_list.pack_start(lines_item_number, True)
        lines_list.pack_start(lines_item_name, True)

        lines_list.add_attribute(lines_item_number, 'text', 0)
        lines_list.add_attribute(lines_item_name, 'text', 1)

        lines_list.set_cell_data_func(lines_item_number, self.line_number_cell_cb)

        for line in self.stan.lines():
            lines_model.append([ '' , line['name'], line['id'] ])

        lines_list.connect('changed', self.show_line_timetable)
        lines_list.set_model(lines_model)

        alignment_lines_list = gtk.Alignment(yscale=0.1)
        alignment_lines_list.add(lines_list)
        lines_navigation.pack_end(alignment_lines_list)
        #lines_navigation.attach(lines_list, 1, 2, 0, 1, xoptions=gtk.SHRINK, yoptions=gtk.FILL)

        vbox = gtk.VBox()

        alignment_lines_navigation = gtk.Alignment(xscale=1.0, yscale=0.1)
        alignment_lines_navigation.add(lines_navigation)

    	vbox.pack_start(alignment_lines_navigation, False)

        self.timetable = StanTimetable()
        self.timetable.create()
        self.timetable.set_activated_callback(self.timetable_row_clicked)

        #alignment_tt = gtk.Alignment(yscale=0.9)
        #alignment_tt.add(self.timetable)
        vbox.pack_start(self.timetable, True, True)

        #lines_navigation.attach(self.timetable, 0, 2, 1, 2, xoptions=gtk.EXPAND, yoptions=gtk.EXPAND, xpadding=1, ypadding=0)
        #lines_navigation.pack_start(self.timetable)

        tab_lines.add(vbox)
    	return tab_lines

    def show_line_timetable(self, selection):
        self.timetable.load( self.stan.lines()[selection.get_active()], time.strftime("%d/%m/%Y"), time.strftime("%H"), 0 )

    def timetable_row_clicked(self, station):
        if self.last_station != station['name']:
            if self.last_station != False:
                self.tabs.remove(self.tab_map)
            self.last_station = station['name']
            self.tab_map = self.tab_geomap(station)
            self.tabs.append_page(self.tab_map, gtk.Label(station['name']))
            self.tabs.show_all()
            self.tabs.set_current_page(1)

    def tab_stations(self):
    	tab_stations = gtk.Frame(None) #'Recherche par arrets')

    	list_stations = gtk.Combo()
    	list_stations.set_popdown_strings([])

    	tab_stations.add(list_stations)

    	return tab_stations

    def tab_geomap(self, station):
        tab_map = gtk.Frame(None)
        map_button = gtk.Button()
        #map_label = gtk.Label(u"Link to map")
        map_button.connect('clicked', self.open_map, station['href'])

        tab_map.add(map_button)
        return tab_map

    def open_map(self, data, url):
        webbrowser.open(url)

    def run(self):
    	self.window.show_all()
    	gtk.main()

