
import os

from distutils.core import setup

setup(	name='pyStan',
	version='0.1.0',
	package_dir = {'': 'src'},
	packages = ['pystan', 'pystan.lib'],
	data_files = [
		('share/pixmaps',             ['res/desktop/pystan_icon_26x26.png']),
		('share/applications/hildon', ['res/desktop/pystan.desktop']),
    ]
)
