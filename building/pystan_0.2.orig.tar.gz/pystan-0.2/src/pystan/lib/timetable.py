# -*- coding: UTF-8 -*-

import gtk
import sys

from stan import STAN

class StanTimetable(gtk.VBox):

    def create(self):
        self.current_timetable = False
        self.navigation = False
        self.navigation_pages = []

    def set_activated_callback(self, new_callback):
        self.cell_activated = new_callback

    def cell_activated(self, data):
        print data

    def __cell_activated(self, timetable_view=None, cell_position=None, column_view=None):
        if len(cell_position) == 1:
            station = self.timetable_stations[ cell_position[0] ]
            station['name'] = self.timetable_struct[ cell_position[0] ][0]
            self.cell_activated(station)

    def navigation_buttons(self):
        box = gtk.HBox()

        current = self.navigation_pages[len(self.navigation_pages)-1]

        #previous_page = None
        #if len(self.navigation_pages) > 0:
        #    previous_page = gtk.Button(u"<")
        #    previous_page.connect('clicked', self.load_by_params, self.navigation_pages[len(self.navigation_pages)-1])

        if self.timetable_navigation.has_key('next'):
            image = gtk.Image()
            image.set_from_stock(gtk.STOCK_GO_FORWARD, 48)
            next = gtk.Button()
            next.add(image)
            index_next = self.timetable_navigation['next']
            next_nav = current.copy(); next_nav.update({ 'hour':int(index_next) })
            next.connect('clicked',  self.load_by_params, next_nav)
            box.pack_end(next,False,False)

        if self.timetable_navigation.has_key('prev'):
            image = gtk.Image()
            image.set_from_stock(gtk.STOCK_GO_BACK, 48)
            index_prev = self.timetable_navigation['prev']
            prev = gtk.Button()
            prev.add(image)
            prev_nav = current.copy(); prev_nav.update({'hour':int(index_prev) })
            prev.connect('clicked',  self.load_by_params, prev_nav)
            box.pack_start(prev,False,False)

        invert = gtk.Button()
        invert_nav = current.copy(); invert_nav.update({'direction':int(not invert_nav['direction'])})
        invert.connect('clicked',  self.load_by_params, invert_nav)
        image = gtk.Image()
        if current['direction']:
            image.set_from_stock(gtk.STOCK_SORT_DESCENDING, 48)
        else:
            image.set_from_stock(gtk.STOCK_SORT_ASCENDING, 48)
        invert.add(image)
        box.add(invert)

        alignment_box_navigation = gtk.Alignment(xscale=1.0,yscale=0.1)
        alignment_box_navigation.add(box)
        return alignment_box_navigation

    def load_by_params(self, widget, params):
        if params.has_key('pop') and params['pop'] and len(self.navigation_pages) > 0:
            self.navigation_pages.pop(len(self.navigation_pages)-1)

        self.load(params['lineobj'], params['date'], params['hour'], params['direction'], params['bypass'])

    def load(self, lineobj, date, hour, direction, bypass=False):

        params = {'lineobj':lineobj, 'date':date, 'hour':hour, 'direction':direction, 'bypass':True }

        if (self.current_timetable):
            self.remove(self.current_timetable)

        if (self.navigation):
            self.remove(self.navigation)

        self.timetable_struct = STAN().load_timetable(lineobj['id'], params, bypass)

        if self.timetable_struct is None or (self.timetable_struct.has_key('timetable') and len(self.timetable_struct['timetable']) == 0):
            self.current_timetable = gtk.VBox()
            self.current_timetable.add(gtk.Label(u"No timetable available for line \n%s" % lineobj['name']))

            if len(self.navigation_pages) > 0:
                go_previous_page = gtk.Button(u"Get back")
                back_params = self.navigation_pages[len(self.navigation_pages)-1]
                back_params['pop'] = True
                go_previous_page.connect('clicked', self.load_by_params, back_params)
                self.current_timetable.add(go_previous_page)

        elif self.timetable_struct == False:
            self.current_timetable = gtk.VBox()
            self.current_timetable.add(gtk.Label(u"No recent timetable available for line \n%s" % lineobj['name']))
            bypass_button = gtk.Button(u"See old local timetable")
            bypass_button.connect("clicked", self.load_by_params, params)
            self.current_timetable.add(bypass_button)

        elif len(self.timetable_struct['timetable']) > 0:
            self.navigation_pages.append(params)

            self.timetable_navigation = self.timetable_struct['navigation']
            self.timetable_stations = self.timetable_struct['stations']
            self.timetable_struct = self.timetable_struct['timetable']

            #self.timetable_store = gtk.ListStore(([str] * len(self.timetable_struct[0])))
            # beurk

            if len(self.timetable_struct[0]) < 7:
                for k,v in enumerate(self.timetable_struct):
                    self.timetable_struct[k].append('-')

            self.timetable_store = gtk.ListStore(str, str, str, str, str, str, str)
            for k,line in enumerate(self.timetable_struct):
                self.timetable_store.append( line )

            self.timetable_view = gtk.TreeView(self.timetable_store)

            self.timetable_view.connect("row-activated", self.__cell_activated)

            column_name = gtk.TreeViewColumn(u"Name")
            self.timetable_view.append_column(column_name)
            cell = gtk.CellRendererText()
            cell.set_property('scale', 0.8)
            column_name.pack_start(cell, True)
            column_name.add_attribute(cell, 'text', 0)

            nb_curses_columns = len(self.timetable_struct[0])-1

            for i in range(nb_curses_columns):
                column = gtk.TreeViewColumn(u"Schedules")
                self.timetable_view.append_column(column)
                cell = gtk.CellRendererText()
                cell.set_property('xalign', 0.5)
                cell.set_property('scale', 0.8)
                cell.set_property('xpad', 9)
                column.pack_end(cell, True)
                column.add_attribute(cell, 'text', i+1)

            #self.timetable_view.set_property('search_column', 0)
            #self.timetable_view.set_property('enable-search', True)
            #self.timetable_view.set_property('headers-clickable', True)

            self.current_timetable = gtk.ScrolledWindow()
            self.current_timetable.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)

            self.current_timetable.add_with_viewport(self.timetable_view)

            if self.navigation:
                self.remove(self.navigation)
            self.navigation = self.navigation_buttons()
            self.add(self.navigation)

        self.add(self.current_timetable)
        self.show_all()
